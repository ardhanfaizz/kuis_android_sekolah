package com.example.kuisuts;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class TampilActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText editTextKode, editTextNama, editTextAkreditasi,editTextAlamat ;
    private Button buttonUpdate, buttonDelete;
    private String kode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampil);

        Intent intent = getIntent();

        kode = intent.getStringExtra(konfigurasi.EMP_KODE);

        editTextKode = findViewById(R.id.editTextKode);
        editTextNama = findViewById(R.id.editTextNama);
        editTextAkreditasi = findViewById(R.id.editTextAkreditasi);
        editTextAlamat = findViewById(R.id.editTextAlamat);

        buttonUpdate = findViewById(R.id.buttonUpdate);
        buttonDelete = findViewById(R.id.buttonDelete);

        buttonUpdate.setOnClickListener(this);
        buttonDelete.setOnClickListener(this);

        editTextKode.setText(kode);

        getSekolah();
    }

    private void getSekolah(){
        class GetSekolah extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(TampilActivity.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                showSekolah(s);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(konfigurasi.URL_GET_EMP,kode);
                return s;
            }
        }
        GetSekolah ge = new GetSekolah();
        ge.execute();
    }

    private void showSekolah(String json){
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(konfigurasi.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            String name = c.getString(konfigurasi.TAG_NAMA);
            String akreditasi = c.getString(konfigurasi.TAG_AKREDITASI);
            String alamat = c.getString(konfigurasi.TAG_ALAMAT);


            editTextNama.setText(name);
            editTextAkreditasi.setText(akreditasi);
            editTextAlamat.setText(alamat);


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void updateSekolah(){
        final String nama = editTextNama.getText().toString().trim();
        final String akreditasi = editTextAkreditasi.getText().toString().trim();
        final String alamat = editTextAlamat.getText().toString().trim();


        class UpdateSekolah extends AsyncTask<Void,Void,String>{
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(TampilActivity.this,"Updating...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(TampilActivity.this,s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put(konfigurasi.KEY_EMP_KODE,kode);
                hashMap.put(konfigurasi.KEY_EMP_NAMA,nama);
                hashMap.put(konfigurasi.KEY_EMP_AKREDITASI,akreditasi);
                hashMap.put(konfigurasi.KEY_EMP_ALAMAT,alamat);


                RequestHandler rh = new RequestHandler();

                String s = rh.sendPostRequest(konfigurasi.URL_UPDATE_EMP,hashMap);

                return s;
            }
        }

        UpdateSekolah ue = new UpdateSekolah();
        ue.execute();
    }



    private void deleteSekolah(){
        class DeleteSekolah extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(TampilActivity.this, "Updating...", "Tunggu...", false, false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(TampilActivity.this, s, Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(konfigurasi.URL_DELETE_EMP, kode);
                return s;
            }
        }

        DeleteSekolah de = new DeleteSekolah();
        de.execute();
    }

    private void confirmDeleteSekolah(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Apakah Kamu Yakin Ingin Menghapus Data Sekolah ini?");

        alertDialogBuilder.setPositiveButton("Ya",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        deleteSekolah();
                        startActivity(new Intent(TampilActivity.this,TampilSemuaActivity.class));
                    }
                });

        alertDialogBuilder.setNegativeButton("Tidak",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    @Override
    public void onClick(View v) {
        if(v == buttonUpdate){
            updateSekolah();
        }

        if(v == buttonDelete){
            confirmDeleteSekolah();
        }
    }
}

package com.example.kuisuts;

public class konfigurasi {
    public static final String URL_ADD="http://192.168.26.104/api/tambah.php";
    public static final String URL_GET_ALL = "http://192.168.26.104/api/tampilsemua.php";
    public static final String URL_GET_EMP = "http://192.168.26.104/api/tampil.php?kode=";
    public static final String URL_UPDATE_EMP = "http://192.168.26.104/api/update.php";
    public static final String URL_DELETE_EMP = "http://192.168.26.104/api/hapus.php?kode=";

    //Dibawah ini merupakan Kunci yang akan digunakan untuk mengirim permintaan ke Skrip PHP
    public static final String KEY_EMP_KODE = "kode";
    public static final String KEY_EMP_NAMA = "nama";
    public static final String KEY_EMP_AKREDITASI = "akreditasi"; //desg itu variabel untuk posisi
    public static final String KEY_EMP_ALAMAT = "alamat"; //salary itu variabel untuk gajih

    //JSON Tags
    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_KODE = "kode";
    public static final String TAG_NAMA = "nama";
    public static final String TAG_AKREDITASI = "akreditasi";
    public static final String TAG_ALAMAT = "alamat";

    //ID karyawan
    //emp itu singkatan dari Employee
    public static final String EMP_KODE = "emp_kode";

}

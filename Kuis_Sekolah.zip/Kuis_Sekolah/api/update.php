<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
		//MEndapatkan Nilai Dari Variable

		$nama = $_POST['nama'];
		$akreditasi = $_POST['akreditasi'];
		$alamat = $_POST['alamat'];

		//import file koneksi database
		require_once('koneksi.php');

		//Membuat SQL Query
		$sql = "UPDATE sekolahan SET nama = '$nama', akreditasi = '$akreditasi', alamat = '$alamat' WHERE kode = '$kode';";

		//Meng-update Database
		if(mysqli_query($con,$sql)){
		echo 'Berhasil Update ';
		}else{
		echo 'Gagal Update';
		}

		mysqli_close($con);
	} ?>

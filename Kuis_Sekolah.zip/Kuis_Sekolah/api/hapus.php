<?php


require_once('koneksi.php');
$sql="DELETE FROM sekolahan WHERE kode='$kode'";

if (mysqli_query($con,$sql)) {
  echo 'Sukses Menghapus';
}
else{
  echo 'Maaf! Gagal Menghapus';
}
mysqli_close($con);
 ?>

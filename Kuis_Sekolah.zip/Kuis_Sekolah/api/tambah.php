<?php


	if($_SERVER['REQUEST_METHOD']=='POST'){

		//Mendapatkan Nilai Variable
		$nama = $_POST['nama'];
		$akreditasi = $_POST['akreditasi'];
		$alamat = $_POST['alamat'];

		//Pembuatan Syntax SQL
		$sql = "INSERT INTO sekolahan (nama, akreditasi, alamat) VALUES ('$nama','$akreditasi','$alamat')";

		//Import File Koneksi database
		require_once('koneksi.php');

		//Eksekusi Query database
		if(mysqli_query($con,$sql)){
		echo 'Berhasil Menambahkan Sekolah';
		}else{
		echo 'Gagal Menambahkan Sekolah';
		}

		mysqli_close($con);
	}
?>
